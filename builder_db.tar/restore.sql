--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.4 (Ubuntu 12.4-0ubuntu0.20.04.1)
-- Dumped by pg_dump version 12.4 (Ubuntu 12.4-0ubuntu0.20.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE builder_pattern_development;
--
-- Name: builder_pattern_development; Type: DATABASE; Schema: -; Owner: yair
--

CREATE DATABASE builder_pattern_development WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE builder_pattern_development OWNER TO yair;

\connect builder_pattern_development

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: addresses; Type: TABLE; Schema: public; Owner: yair
--

CREATE TABLE public.addresses (
    id bigint NOT NULL,
    street character varying,
    external_number character varying,
    country character varying,
    city character varying,
    state character varying,
    zip_code character varying,
    addressable_id integer,
    addressable_type character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.addresses OWNER TO yair;

--
-- Name: addresses_id_seq; Type: SEQUENCE; Schema: public; Owner: yair
--

CREATE SEQUENCE public.addresses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.addresses_id_seq OWNER TO yair;

--
-- Name: addresses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: yair
--

ALTER SEQUENCE public.addresses_id_seq OWNED BY public.addresses.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: yair
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.ar_internal_metadata OWNER TO yair;

--
-- Name: clients; Type: TABLE; Schema: public; Owner: yair
--

CREATE TABLE public.clients (
    id bigint NOT NULL,
    name character varying,
    email character varying,
    phone character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.clients OWNER TO yair;

--
-- Name: clients_id_seq; Type: SEQUENCE; Schema: public; Owner: yair
--

CREATE SEQUENCE public.clients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.clients_id_seq OWNER TO yair;

--
-- Name: clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: yair
--

ALTER SEQUENCE public.clients_id_seq OWNED BY public.clients.id;


--
-- Name: companies; Type: TABLE; Schema: public; Owner: yair
--

CREATE TABLE public.companies (
    id bigint NOT NULL,
    business_name character varying,
    rfc character varying,
    email character varying,
    phone character varying,
    active character varying,
    contact character varying,
    user_id bigint NOT NULL,
    fiscal_name character varying,
    company_type_id integer,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.companies OWNER TO yair;

--
-- Name: companies_id_seq; Type: SEQUENCE; Schema: public; Owner: yair
--

CREATE SEQUENCE public.companies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.companies_id_seq OWNER TO yair;

--
-- Name: companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: yair
--

ALTER SEQUENCE public.companies_id_seq OWNED BY public.companies.id;


--
-- Name: company_types; Type: TABLE; Schema: public; Owner: yair
--

CREATE TABLE public.company_types (
    id bigint NOT NULL,
    name character varying,
    code character varying,
    affiliation character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.company_types OWNER TO yair;

--
-- Name: company_types_id_seq; Type: SEQUENCE; Schema: public; Owner: yair
--

CREATE SEQUENCE public.company_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.company_types_id_seq OWNER TO yair;

--
-- Name: company_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: yair
--

ALTER SEQUENCE public.company_types_id_seq OWNED BY public.company_types.id;


--
-- Name: fiscal_infos; Type: TABLE; Schema: public; Owner: yair
--

CREATE TABLE public.fiscal_infos (
    id bigint NOT NULL,
    ri character varying,
    account_statement character varying,
    proof_of_address character varying,
    incorporation_act character varying,
    start_of_operation timestamp without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    company_id bigint
);


ALTER TABLE public.fiscal_infos OWNER TO yair;

--
-- Name: fiscal_infos_id_seq; Type: SEQUENCE; Schema: public; Owner: yair
--

CREATE SEQUENCE public.fiscal_infos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fiscal_infos_id_seq OWNER TO yair;

--
-- Name: fiscal_infos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: yair
--

ALTER SEQUENCE public.fiscal_infos_id_seq OWNED BY public.fiscal_infos.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: yair
--

CREATE TABLE public.products (
    id bigint NOT NULL,
    name character varying,
    price integer,
    uid character varying,
    company_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.products OWNER TO yair;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: yair
--

CREATE SEQUENCE public.products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_id_seq OWNER TO yair;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: yair
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: purchase_concepts; Type: TABLE; Schema: public; Owner: yair
--

CREATE TABLE public.purchase_concepts (
    id bigint NOT NULL,
    purchase_id bigint NOT NULL,
    unit_price character varying,
    total character varying,
    amount character varying,
    product_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.purchase_concepts OWNER TO yair;

--
-- Name: purchase_concepts_id_seq; Type: SEQUENCE; Schema: public; Owner: yair
--

CREATE SEQUENCE public.purchase_concepts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_concepts_id_seq OWNER TO yair;

--
-- Name: purchase_concepts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: yair
--

ALTER SEQUENCE public.purchase_concepts_id_seq OWNED BY public.purchase_concepts.id;


--
-- Name: purchases; Type: TABLE; Schema: public; Owner: yair
--

CREATE TABLE public.purchases (
    id bigint NOT NULL,
    seller_id integer,
    buyer_id integer,
    total numeric,
    status integer,
    purchase_type character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.purchases OWNER TO yair;

--
-- Name: purchases_id_seq; Type: SEQUENCE; Schema: public; Owner: yair
--

CREATE SEQUENCE public.purchases_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchases_id_seq OWNER TO yair;

--
-- Name: purchases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: yair
--

ALTER SEQUENCE public.purchases_id_seq OWNED BY public.purchases.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: yair
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO yair;

--
-- Name: users; Type: TABLE; Schema: public; Owner: yair
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    email character varying DEFAULT ''::character varying NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL,
    role integer NOT NULL,
    encrypted_password character varying DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying,
    reset_password_sent_at timestamp without time zone,
    remember_created_at timestamp without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO yair;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: yair
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO yair;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: yair
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: addresses id; Type: DEFAULT; Schema: public; Owner: yair
--

ALTER TABLE ONLY public.addresses ALTER COLUMN id SET DEFAULT nextval('public.addresses_id_seq'::regclass);


--
-- Name: clients id; Type: DEFAULT; Schema: public; Owner: yair
--

ALTER TABLE ONLY public.clients ALTER COLUMN id SET DEFAULT nextval('public.clients_id_seq'::regclass);


--
-- Name: companies id; Type: DEFAULT; Schema: public; Owner: yair
--

ALTER TABLE ONLY public.companies ALTER COLUMN id SET DEFAULT nextval('public.companies_id_seq'::regclass);


--
-- Name: company_types id; Type: DEFAULT; Schema: public; Owner: yair
--

ALTER TABLE ONLY public.company_types ALTER COLUMN id SET DEFAULT nextval('public.company_types_id_seq'::regclass);


--
-- Name: fiscal_infos id; Type: DEFAULT; Schema: public; Owner: yair
--

ALTER TABLE ONLY public.fiscal_infos ALTER COLUMN id SET DEFAULT nextval('public.fiscal_infos_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: yair
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: purchase_concepts id; Type: DEFAULT; Schema: public; Owner: yair
--

ALTER TABLE ONLY public.purchase_concepts ALTER COLUMN id SET DEFAULT nextval('public.purchase_concepts_id_seq'::regclass);


--
-- Name: purchases id; Type: DEFAULT; Schema: public; Owner: yair
--

ALTER TABLE ONLY public.purchases ALTER COLUMN id SET DEFAULT nextval('public.purchases_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: yair
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: addresses; Type: TABLE DATA; Schema: public; Owner: yair
--

COPY public.addresses (id, street, external_number, country, city, state, zip_code, addressable_id, addressable_type, created_at, updated_at) FROM stdin;
\.
COPY public.addresses (id, street, external_number, country, city, state, zip_code, addressable_id, addressable_type, created_at, updated_at) FROM '$$PATH$$/3075.dat';

--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: yair
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
\.
COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM '$$PATH$$/3093.dat';

--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: yair
--

COPY public.clients (id, name, email, phone, created_at, updated_at) FROM stdin;
\.
COPY public.clients (id, name, email, phone, created_at, updated_at) FROM '$$PATH$$/3077.dat';

--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: yair
--

COPY public.companies (id, business_name, rfc, email, phone, active, contact, user_id, fiscal_name, company_type_id, created_at, updated_at) FROM stdin;
\.
COPY public.companies (id, business_name, rfc, email, phone, active, contact, user_id, fiscal_name, company_type_id, created_at, updated_at) FROM '$$PATH$$/3079.dat';

--
-- Data for Name: company_types; Type: TABLE DATA; Schema: public; Owner: yair
--

COPY public.company_types (id, name, code, affiliation, created_at, updated_at) FROM stdin;
\.
COPY public.company_types (id, name, code, affiliation, created_at, updated_at) FROM '$$PATH$$/3081.dat';

--
-- Data for Name: fiscal_infos; Type: TABLE DATA; Schema: public; Owner: yair
--

COPY public.fiscal_infos (id, ri, account_statement, proof_of_address, incorporation_act, start_of_operation, created_at, updated_at, company_id) FROM stdin;
\.
COPY public.fiscal_infos (id, ri, account_statement, proof_of_address, incorporation_act, start_of_operation, created_at, updated_at, company_id) FROM '$$PATH$$/3083.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: yair
--

COPY public.products (id, name, price, uid, company_id, created_at, updated_at) FROM stdin;
\.
COPY public.products (id, name, price, uid, company_id, created_at, updated_at) FROM '$$PATH$$/3085.dat';

--
-- Data for Name: purchase_concepts; Type: TABLE DATA; Schema: public; Owner: yair
--

COPY public.purchase_concepts (id, purchase_id, unit_price, total, amount, product_id, created_at, updated_at) FROM stdin;
\.
COPY public.purchase_concepts (id, purchase_id, unit_price, total, amount, product_id, created_at, updated_at) FROM '$$PATH$$/3087.dat';

--
-- Data for Name: purchases; Type: TABLE DATA; Schema: public; Owner: yair
--

COPY public.purchases (id, seller_id, buyer_id, total, status, purchase_type, created_at, updated_at) FROM stdin;
\.
COPY public.purchases (id, seller_id, buyer_id, total, status, purchase_type, created_at, updated_at) FROM '$$PATH$$/3089.dat';

--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: yair
--

COPY public.schema_migrations (version) FROM stdin;
\.
COPY public.schema_migrations (version) FROM '$$PATH$$/3092.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: yair
--

COPY public.users (id, email, name, role, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, created_at, updated_at) FROM stdin;
\.
COPY public.users (id, email, name, role, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, created_at, updated_at) FROM '$$PATH$$/3091.dat';

--
-- Name: addresses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: yair
--

SELECT pg_catalog.setval('public.addresses_id_seq', 8, true);


--
-- Name: clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: yair
--

SELECT pg_catalog.setval('public.clients_id_seq', 3, true);


--
-- Name: companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: yair
--

SELECT pg_catalog.setval('public.companies_id_seq', 4, true);


--
-- Name: company_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: yair
--

SELECT pg_catalog.setval('public.company_types_id_seq', 2, true);


--
-- Name: fiscal_infos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: yair
--

SELECT pg_catalog.setval('public.fiscal_infos_id_seq', 4, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: yair
--

SELECT pg_catalog.setval('public.products_id_seq', 8, true);


--
-- Name: purchase_concepts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: yair
--

SELECT pg_catalog.setval('public.purchase_concepts_id_seq', 12, true);


--
-- Name: purchases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: yair
--

SELECT pg_catalog.setval('public.purchases_id_seq', 6, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: yair
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- Name: addresses addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: yair
--

ALTER TABLE ONLY public.addresses
    ADD CONSTRAINT addresses_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: yair
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: yair
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: yair
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: company_types company_types_pkey; Type: CONSTRAINT; Schema: public; Owner: yair
--

ALTER TABLE ONLY public.company_types
    ADD CONSTRAINT company_types_pkey PRIMARY KEY (id);


--
-- Name: fiscal_infos fiscal_infos_pkey; Type: CONSTRAINT; Schema: public; Owner: yair
--

ALTER TABLE ONLY public.fiscal_infos
    ADD CONSTRAINT fiscal_infos_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: yair
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: purchase_concepts purchase_concepts_pkey; Type: CONSTRAINT; Schema: public; Owner: yair
--

ALTER TABLE ONLY public.purchase_concepts
    ADD CONSTRAINT purchase_concepts_pkey PRIMARY KEY (id);


--
-- Name: purchases purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: yair
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: yair
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: yair
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: index_companies_on_company_type_id; Type: INDEX; Schema: public; Owner: yair
--

CREATE INDEX index_companies_on_company_type_id ON public.companies USING btree (company_type_id);


--
-- Name: index_companies_on_user_id; Type: INDEX; Schema: public; Owner: yair
--

CREATE INDEX index_companies_on_user_id ON public.companies USING btree (user_id);


--
-- Name: index_fiscal_infos_on_company_id; Type: INDEX; Schema: public; Owner: yair
--

CREATE INDEX index_fiscal_infos_on_company_id ON public.fiscal_infos USING btree (company_id);


--
-- Name: index_products_on_company_id; Type: INDEX; Schema: public; Owner: yair
--

CREATE INDEX index_products_on_company_id ON public.products USING btree (company_id);


--
-- Name: index_purchase_concepts_on_product_id; Type: INDEX; Schema: public; Owner: yair
--

CREATE INDEX index_purchase_concepts_on_product_id ON public.purchase_concepts USING btree (product_id);


--
-- Name: index_purchase_concepts_on_purchase_id; Type: INDEX; Schema: public; Owner: yair
--

CREATE INDEX index_purchase_concepts_on_purchase_id ON public.purchase_concepts USING btree (purchase_id);


--
-- Name: index_purchases_on_buyer_id; Type: INDEX; Schema: public; Owner: yair
--

CREATE INDEX index_purchases_on_buyer_id ON public.purchases USING btree (buyer_id);


--
-- Name: index_purchases_on_seller_id; Type: INDEX; Schema: public; Owner: yair
--

CREATE INDEX index_purchases_on_seller_id ON public.purchases USING btree (seller_id);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: yair
--

CREATE UNIQUE INDEX index_users_on_email ON public.users USING btree (email);


--
-- Name: index_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: yair
--

CREATE UNIQUE INDEX index_users_on_reset_password_token ON public.users USING btree (reset_password_token);


--
-- Name: products fk_rails_438d5b34ce; Type: FK CONSTRAINT; Schema: public; Owner: yair
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT fk_rails_438d5b34ce FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: purchase_concepts fk_rails_55d25c59db; Type: FK CONSTRAINT; Schema: public; Owner: yair
--

ALTER TABLE ONLY public.purchase_concepts
    ADD CONSTRAINT fk_rails_55d25c59db FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: purchase_concepts fk_rails_b2495e0782; Type: FK CONSTRAINT; Schema: public; Owner: yair
--

ALTER TABLE ONLY public.purchase_concepts
    ADD CONSTRAINT fk_rails_b2495e0782 FOREIGN KEY (purchase_id) REFERENCES public.purchases(id);


--
-- Name: companies fk_rails_e57cb42012; Type: FK CONSTRAINT; Schema: public; Owner: yair
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT fk_rails_e57cb42012 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: fiscal_infos fk_rails_f4e1d2fc7a; Type: FK CONSTRAINT; Schema: public; Owner: yair
--

ALTER TABLE ONLY public.fiscal_infos
    ADD CONSTRAINT fk_rails_f4e1d2fc7a FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- PostgreSQL database dump complete
--

